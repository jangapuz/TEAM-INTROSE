/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author pauldelgado
 */
public class OppItems {
    
    public int oppId;
    public String itemId;

    /**
     * @return the oppId
     */
    public int getOppId() {
        return oppId;
    }

    /**
     * @param oppId the oppId to set
     */
    public void setOppId(int oppId) {
        this.oppId = oppId;
    }

    /**
     * @return the itemId
     */
    public String getItemId() {
        return itemId;
    }

    /**
     * @param itemId the itemId to set
     */
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }
    
}

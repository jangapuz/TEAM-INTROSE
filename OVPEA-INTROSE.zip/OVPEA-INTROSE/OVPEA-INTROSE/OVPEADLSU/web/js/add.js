$(function() {

	$('#startDate').datetimepicker({
 		format: "YYYY-MM-DD"
 	});


 });